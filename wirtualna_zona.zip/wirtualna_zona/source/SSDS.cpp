/* ----------------------------------------------------------- */
/*                                                             */
/*               _ ___       _   _   _                         */
/*              /_\ | |_/ _ /_\ |_| |_|                        */
/*              | | | | \   | | |   |                          */
/*              =========   =========                          */
/*                                                             */
/*      Application Example using the ATK Real-Time API        */
/*                                                             */
/*       Machine Intelligence Laboratory (Speech Group)        */
/*        Cambridge University Engineering Department          */
/*                  http://mi.eng.cam.ac.uk/                   */
/*                                                             */
/*               Copyright Steve Young 2000-2003               */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*					edited by kxl                              */
/* ----------------------------------------------------------- */


static const char * version="!HVER!VirtWife:   1.0beta [KXL 24/05/05]";

#include "AMonitor.h"
#include "ASource.h"
#include "ACode.h"
#include "ARec.h"
#include "shellapi.h"

// ---------------- Globals To Define the Recognition System -----------------

// Information Channels (plumbing)
ABuffer *auChan;   // carries audio from source to Coder
ABuffer *feChan;   // carries feat vecs from Coder to Recogniser
ABuffer *ansChan;  // carries answers from Rec back to Application
// Active components (threads)
ASource *ain;      // audio source
ACode *acode;      // coder
ARec *arec;      // viterbi recogniser
AMonitor *amon;    // system monitor
// Global resources
ARMan *rman;       // resource manager for dict, grammars and HMMSet
AHmms *hset;       // HMM set is global since it never changes
ADict *dict;       // ditto dictionary (though it can be edited if desired)
AGram *ggrm;       // global grammar, always active

SHELLEXECUTEINFO ShExecInfo={0};

void myReplace(string &temp2, string toFind, string replaceWith){
	int pos;
    while ((pos = temp2.find(toFind)) != string::npos)
          temp2.replace(pos,toFind.size(),replaceWith);
}

// output a prompt (just a text string for this simple demo )
void Talk(string s)
{
	string temp = "Syn_kxl "+s;

	string temp2(s);
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");
	myReplace(temp2,"�","�");

	
	printf("\n%s\n",temp2.c_str());
	//if(ain->stopped!=TRUE) ain->SendMessage("stop()");
	
	
	ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	ShExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
	ShExecInfo.hwnd = NULL;
	ShExecInfo.lpVerb = NULL;
	ShExecInfo.lpFile = "java";		
	ShExecInfo.lpParameters = temp.c_str();	
	ShExecInfo.lpDirectory = NULL;
	ShExecInfo.nShow = SW_SHOW;
	ShExecInfo.hInstApp = NULL;	
	ShellExecuteEx(&ShExecInfo);
	WaitForSingleObject(ShExecInfo.hProcess,INFINITE);
	//Sleep(200);
	//if(ain->stopped==TRUE)ain->SendMessage("start()");
}


typedef enum { unknown, unconfirmed, grounded, cancelled } SlotStatus;
static const float minconf = 0.5;

class QA {
public:
	QA(const string& aname,			// name of qa object
		const string& aprompt,		// query prompt
		const string& gramfile,		// name of grammar file
		const string& ahelp,        // help message
		string** asublattice,
		QA** anextQA,
		const int& aqaCount);		
	QA(const string& aprompt);		// query prompt

	void Listen(string rgroup);	// listen using given res group and update slot value
	void Ask();							// ask question, record answer and set status
	void Check();						// check answer and set status
	void GetSlot();               // get a value for the slot by asking and checking
	void Show();						// show current slot status
	void Reset();
	bool fSublattice();
	SlotStatus status;				// slot status
	string  value;						// slot value
	float  curconf;					// current input
	string curtag;
	string curwords;
private:
	//----------my addd-------kxl----------------------------
	string **sublattice;           //podgramatyki
	QA **nextQA;                   //odpowiedzi na pytania
	int qaCount;                  //ilosc podgramatyk (i jednoczesnie odpowiedzi)
	int foundSublattice;					//znaleziona gramatyka

	string name;                  // name of slot (also name of semantic tag)
	string prompt;						// question
	string help;						// help string
	ResourceGroup *ask;
	ResourceGroup *chk;
};

// construct a QA object with given prompt and grammar
QA::QA(const string& aname, const string& aprompt, 
       const string& gramfile, const string& ahelp, 
	   string** asublattice, QA** anextQA, const int& aqaCount)
{
	// save the prompts
	prompt = aprompt; help = ahelp; name = aname;
	sublattice = asublattice; nextQA = anextQA; qaCount = aqaCount;
	// create grammar specific to this question
	AGram *g1 = new AGram(name,gramfile);
	rman->StoreGram(g1);
	ask = rman->NewGroup(name+"-ask");
	ask->AddHMMs(hset);  // Add the global resources
	ask->AddDict(dict);
	ask->AddGram(ggrm);  // include global grammar in parallel with 
	ask->AddGram(g1);     // qa specific grammar
	// create copy of ask but prepend "No" to front of qa grammar
	// and add confirm in parallel
	chk = rman->NewGroup(name+"-chk");
	chk->AddHMMs(hset);  // Add the global resources
	chk->AddDict(dict);
	chk->AddGram(ggrm);  // include global grammar in parallel with 
	AGram *g2 = new AGram(*g1);    // copy g1
	rman->StoreGram(g2);
	g2->OpenEdit();
	GramSubN *s = g2->main;        // prepend "NO" to front with skip to end
	GramNode *ent = s->NewNullNode(99);
	GramNode *no = s->NewWordNode("NO","no");
	GramNode *yes =s->NewCallNode("confirm","yes");
	s->AddLink(ent,no); s->AddLink(ent,yes); s->AddLink(yes,s->exit);
	s->AddLink(no,s->entry); s->AddLink(no,s->exit); 
	s->entry = ent;
	g2->CloseEdit();
	chk->AddGram(g2);    // Add the new "correction" grammar
	// initial status is unknown
	status = unknown; value = ""; foundSublattice = -1;
}
//only for displaying answer
QA::QA(const string& aprompt){
	prompt = aprompt;
	status = unknown; value = "_null_";
	foundSublattice = 0;
}

// Reset slot values for a new dialogue
void QA::Reset(){
	status = unknown; value = "";
}

// For debugging only
void QA::Show(){
	string s = "???";
	
	switch (status){
			case unknown:		s = "unknown";			break;
			case unconfirmed: s = "unconfirmed";	break;
			case grounded:		s = "grounded";		break;
			case cancelled:	s = "cancelled";		break;
	}
	printf("Slot: %s:  status=%s  value=%s  [cur=%s(%s) %.1f]\n",
			name.c_str(),s.c_str(),value.c_str(),curtag.c_str(),curwords.c_str(),curconf);
}

// listen to rec packets and construct slot value
void QA::Listen(string rgroup)
{
	APacket p;
	APhraseData *pd;
	string s="";
	float conf=0.0;
	int numwords=0;
	
	curtag=""; curwords="";
	// set the resource group to use and start recognising
	arec->SendMessage("usegrp("+rgroup+")");
	arec->SendMessage("start()");
	// listen to response of form  "tag(w1 w2 ...)"
	do {
      p = ansChan->GetPacket();
		pd = (APhraseData *)p.GetData();
      if (pd->ptype == OpenTag_PT){
			assert(s == "" && numwords == 0);
			do {
				p = ansChan->GetPacket(); pd = (APhraseData *)p.GetData();
				if (pd->ptype == Word_PT) {
					if (s=="") s = pd->word; else s = s + " " + pd->word;
					// printf("{%s[%.2f]}",pd->word.c_str(),pd->confidence);
					conf += pd->confidence; ++numwords;
				}
			}while(pd->ptype != CloseTag_PT && pd->ptype != End_PT);
			curtag = pd->tag;
			curwords = s;
      }
	} while (pd->ptype != End_PT);
	arec->SendMessage("stop()");
	curconf = numwords==0?0.0:conf/numwords;
	//printf("\n     >>Wykryte zosta�o:  %s(%s)[%.1f]\n",curtag.c_str(),curwords.c_str(),curconf);
}

// ask for information
void QA::Ask(){
	bool ok = false;

	do {
		Talk(prompt);
		Listen(ask->gname);
		ok = fSublattice();
		if(ok!=true){
			if (curtag == "command") {
				if (curwords == "HELP") {
					Talk(help);
				}else if (curwords == "CANCEL"){
					ok = true; status = cancelled;
				}
			}
		}
	} while (!ok);
}
//znajduje do ktorej gramatyki nalezy powiedziane zdanie;
bool QA::fSublattice(){
	bool ret = false;
	
	for(int i = 0; i < qaCount; i++){
		if(curtag == *sublattice[i]){
			if (curconf > minconf){
				status = grounded;
			}else{
				status = unconfirmed;
			}			
			value = curtag;
			ret = true;
			foundSublattice = i;
			i = qaCount;
		}else{
			if(*sublattice[i]=="_noMatter_"){
				status = grounded;
				foundSublattice = i;
				i = qaCount;
				ret = true;
			}
		}
	}
	return ret;
}

// confirm current slot value
void QA::Check(){
	bool ok = false;
	do {
		Talk(">>>>D E B U G I N G<<<<< rozpoznane zdanie to<"+curwords+">");
		Listen(chk->gname);
		if (curtag == "command") {
			if (curwords == "HELP") {
				Talk("Masz potwiedzi� czy dobrze Cie zrozumia�am");
			}else if (curwords == "CANCEL"){
				ok = true; status = cancelled;
			}
		}else if (curtag == "yes"){
			ok = true; status = grounded;
		}else if(curtag == "no"){
			ok = true; status = unknown;
		}else ok = fSublattice();
	} while (!ok);
}

void QA::GetSlot()
{
	if(value!="_null_"){
		do {
			Ask();
			while (status == unconfirmed) Check();
		}while (status != grounded && status != cancelled);
		if(status == grounded){
			nextQA[foundSublattice]->GetSlot();
		}else{
			Talk("Jak chcesz..to nie rozmawiam z tob�..nastepnym razem lepiej si� zastan�w!");
		}
	}else{
		Talk(prompt);
	}
}


// ---------------------- Initialisation Code ---------------------------

void Initialise(int argc, char *argv[])
{
  if (InitHTK(argc,argv,version)<SUCCESS){
    HRError(9999,"SSDS: cannot initialise HTK\n");
    throw HTK_Error(9999);
  }
  printf("\n      ATK based Virtual Wife       \n");
  printf("_____________________________________\n");
  printf("!!how to talk: wait for question,    \n");
  printf("!!answer, and wait for wife's reply  \n\n");
}

void BuildRecogniser()
{
  // create some plumbing
  auChan = new ABuffer("auChan");
  feChan = new ABuffer("feChan");
  ansChan = new ABuffer("ansChan");
  // create a resource manager
  rman = new ARMan;
  // create active components linked by buffers
  ain = new ASource("AIn",auChan);
  acode = new ACode("ACode",auChan,feChan);
  arec = new ARec("ARec",feChan,ansChan,rman);
  // create global fixed resources
  hset = new AHmms("HmmSet"); // load info in config
  AObsData *od = acode->GetSpecimen();
  if (!hset->CheckCompatible(&(od->data))){
     HRError(9999,"SSDS: HMM set is not compatible with Coder"); 
     throw ATK_Error(9999);
  }   
  dict = new ADict("ADict");  // load info in config
  ggrm = new AGram("GGram","global.net");
  rman->StoreHMMs(hset);
  rman->StoreDict(dict);
  rman->StoreGram(ggrm);
  // finally create Monitor
  amon = new AMonitor;
  amon->AddComponent(ain);   //register components
  amon->AddComponent(acode); //with the monitor
  amon->AddComponent(arec);
}

void StartRecogniser()
{
  // Start up each component thread
  amon->Start();
  ain->Start(); 
  // uncomment following if completely hands-free
  // ain->SendMessage("start()");
  acode->Start();
  arec->Start();  
  // note recogniser will not actually do anything until it
  // receives a "start" command
}

void ShutDown()
{
  // ask all threads to terminate
  ain->SendMessage("terminate()");
  acode->SendMessage("terminate()");
  arec->SendMessage("terminate()");
  // wait till they actually do it
  ain->Join(); acode->Join();  arec->Join();
  HJoinMonitor();
}

// ------------------------- Application Code ---------------------------

void RunApplication()
{
	string *aniolek_diablicaS[2] = {new string("aniolek"), new string("diablica")};
	string *danie_restauracjeS[2] = {new string("danie"), new string("restauracje")};
	string *matkaride__S[2] = {new string("matka_ride"), new string("_noMatter_")};
	string *piwo_tak_nieS[2] = {new string("piwo_tak"), new string("piwo_nie")};
	string *ktora_restauracjaS[7] ={new string("mcd"),
									new string("spx"),
									new string("pizzh"),
									new string("kfc"),
									new string("komppiw"),
									new string("pier"),
									new string("mariot")
									};
	string *wezfure_zawiozeS[2] = {new string("wez_fure"), new string("zawioze")};
	string *__S[1] = {new string("_noMatter_")};
	string *listaZyczenS[2] = {new string("lista_zyczen"), new string("_noMatter_")};
	string *lodowkaS[1] = {new string("lodowka")};
	string *saldoPortfelaS[3] = {new string("duzo_kasy"),new string("malo_kasy"),new string("nic_kasy")};
	string *potwierdzZaprzeczS[2] = {new string("koszule_tak"), new string("kolusze_nie")};
	string *jestobiad_plotyS[2] = {new string("jest_obiad"), new string("ploty")};
	string *przeprosinyS[2] = {new string("przeprosiny"), new string("_noMatter_")};
	string *potwierdzObaw_ZaprzeczObawS[2] = {new string("potwierdzenie_obow"), new string("zaprzeczenie_obow")};
	string *autobusRide_rowerS[2] = {new string("autobus_ride"), new string("rower_ride")};
	string *bleee_cacyS[2] = {new string("bleee"), new string("cacy")};
	string *higienaS[1] = {new string("_noMatter_")};
	string *gitBleee_goodBadPsieS[2] = {new string("dam_fure"),new string("niedam_fure")};
	string *gitZakup_bleeeZakupS[2] = {new string("git_zakup"),new string("bleee_zakup")};
	string *goodPsie_badPsieS[2] = {new string("good"),new string("bad")};
	string *zakaskiS[1] = {new string("zakaski")};
	string *telewizorS[1] = {new string("telewizor")};
	string *kino_domoweS[2] = {new string("kino_domowe_tak"),new string("kino_domowe_nie")};
	string *kiedys_nigdyS[2] = {new string("kiedys"),new string("nigdy")};
	string *danie_mcdS[1] = {new string("danie_mcd")};
	string *danie_spxS[1] = {new string("danie_spx")};
	string *danie_pizzhS[1] = {new string("danie_pizzh")};
	string *danie_kfcS[1] = {new string("danie_kfc")};
	string *danie_komppiwS[1] = {new string("danie_komppiw")};
	string *danie_pierS[1] = {new string("danie_pier")};
	string *danie_mariotS[1] = {new string("danie_mariot")};
	string *matka_wyjazd_przyjazdS[2] = {new string("matka_wyjazd"),new string("matka_przyjazd")};
	string *porozmawiajmyS[2] = {new string("tak"),new string("nie")};
	
	QA *saldo_portfelaA[3] = {
				new QA("Sk�d masz tyle pieni�dzy?,, Ukrywasz je przede mn�!,, Oddawaj po�ow� i marsz do sklepu!,, Ju� ci� tutaj nie ma."),
				new QA("To co zrobi�e� z reszt�? Przecie� ci zostawiam jedn� dziesi�t� twojej wyp�aty na w�asne potrzeby. Nie szanujesz pieni�dzy.,,, Poka� ile masz!, A z zakup�w przynie� mi paragon i reszt� co do grosza.,,,,, Po�piesz si�, mamusia nie mo�e czeka�. Pami�taj, �e masz po ni� jecha�!"),
				new QA("Ty szmaciarzu!,,,, Ja tu na ciebie czekam a ty si� gdzie� szlajasz i moj� kas� przepuszczasz!, Kt�rej dziwce w tym miesi�cu zasponsorowa�e� nowe futro?,,,, ahhhhhh,,,,, zejd� mi z oczu i bez jedzenia nie wracaj.")
								};

	QA *saldo_portfelaQ = new QA("saldo_portfela",
		"To jak si� troszczysz o to, aby mi niczego nie brakowa�o?,, Biegnij zaraz do sklepu i uzupe�nij zapasy. Przy okazji kup mi podpaski,,, tylko nie te z promocji!,,,,,,,,,,,,, Ile masz pieni�dzy?,,,, Du�o,,,, ma�o,,,, zero?",
		"saldo_portfela.net",
		"HELP? O Co Ci chodzi Skarbie?",
		saldoPortfelaS,
		saldo_portfelaA,
		3);

	QA *saldoPortfela_Q[1] = {saldo_portfelaQ};

	QA *lodowkaQ = new QA("lodowka",
		"A o tiramisu zapomnia�e�!,,,, I jak ja mam tutaj si� z tob� dogadywa�, jak ty mnie w og�le nie s�uchasz. Ja si� staram a ty co?,,, Nawet nie potrafisz mi �niadania przygotowa�.,,,,,ehhhhh,,,,,,, Sprawd� czy mamy w lod�wce jajka?",
		"lodowka.net",
		"HELP? O Co Ci chodzi Skarbie?",
		lodowkaS,
		saldoPortfela_Q,
		1);

	QA *jestobiad_plotyA[2] = {
				new QA("No widzisz,,, staram si�, dwoj�, troj�, nie mam przez ciebie �ycia towarzyskiego, nie wiem co tu si� dzieje,,,,, o tym, �e umar�a staruszka z tamtego domku za osiedlem dowiedzia�am si� a� dwie godziny po odje�dzie karetki. A chcia�am to zobaczy�. Podobno zjad� j� kot?, Nie jestem na bie��co, ograniczasz mnie, jutro sam sobie gotuj, ja jestem um�wiona z J�zkom z klatki obok."),
				new QA("CO? ,,,,Ty si� co tydzie� z kolegami na piwo umawiasz i jest dobrze, a ja chce ma��, kr�tk� godzink� dziennie po�wi�ci� na bie��ce wydarzenia i ju� jest �le., Gdyby nie ja to by� nie wiedzia�, �e s�siadka spod pi�tki um�wi�a si� ostatnio z Tomkiem, tym od fryzjerki.,,, no wiesz kt�rym?,,,,, no.,,,,, gdyby nie ja to by� siedzia�, gnu�nia� po ca�odniowym dniu pracy a tak to dostarczam ci nius�w. Jeste� niewdzi�cznikiem.,,, Jutro sam sobie gotujesz. Um�wi�am si� z  J�zkom z klatki obok.")
		};

	QA *jestobiad_plotyQ = new QA("jest_obiad_ploty",
		"Widzisz,,, a co jak wracasz z pracy? ,,,,,Czeka na ciebie obiad, czy ja siedz� u kole�anek na plotkach?",
		"jest_obiad_ploty.net",
		"HELP? O Co Ci chodzi Skarbie?",
		jestobiad_plotyS,
		jestobiad_plotyA,
		2);

	QA *przeprosinyA[2] = {
				new QA("Ciesz� si�, �e zrozumia�e� sw�j b��d. Ja teraz id� si� po�o�y� a ty mo�esz robi� co chcesz."),
				new QA("Ty mnie w og�le nie rozumiesz. Zrani�e� moje uczucia i wcale tego nie czujesz. Chcia�abym o tym porozmawia�, ale z tob� nie mog�, bo i tak nie zrozumiesz. Nie mam �i� ci dzisiaj tego t�umaczy�,, id� spa�! Ty prze�pij si� na kanapie w salonie i przemy�l to.")
		};

	QA *przeprosiny__Q = new QA("przeprosiny",
		"Bo stary nieudaczniku dawno ju� mi obiecywa�e� now� pralk�! Ta stara, z zesz�ego roku jest za g�o�na,,, nie s�ysz� g�osu ze s�uchawki, dlatego wydawa�o mi si�, �e Ola spod dwunastki przespa�a si� ostatnio z Ry�kiem.,,, a faktycznie przespa�a si� ze Zdzi�kiem. Przez ciebie s�siadka spod czw�rki, kt�rej to powt�rzy�am nazwa�a mnie plotkar�.,, Od dzisiaj sam pierzesz swoje koszule.,,,,,,,,,, Chcesz mnie przeprosi�?",
		"przeprosiny.net",
		"HELP? O Co Ci chodzi Skarbie?",
		przeprosinyS,
		przeprosinyA,
		2);

	QA *jestobiadPloty_przeprosiny__Q[2] = {jestobiad_plotyQ, przeprosiny__Q};
	
	QA *potwierdzZaprzeczQ = new QA("koszule_tak_nie",
		"No widzisz.,,,, Wcale nie pami�tasz co do ciebie m�wi�am.,,, M�j kot mnie bardziej s�ucha ni� ty.,,,, Wiesz co?,,,, ju� nie mam ochoty na to �niadanie. Ja robi� wszystko najlepiej jak potrafi� dla ciebie.,,,,,,,,, Powiedz sam czy nie masz zawsze czystych koszul w szafce?",
		"koszule_tak_nie.net",
		"HELP? O Co Ci chodzi Skarbie?",
		potwierdzZaprzeczS,
		jestobiadPloty_przeprosiny__Q,
		2);

	QA *lodowka_potwierdzZaprzeczQ[2] = {lodowkaQ, potwierdzZaprzeczQ};

	QA *listaZyczenQ = new QA("lista_zyczen",
		"czy ty mnie w og�le suchasz?,,,,,,,,,,,, Co mia�e� mi przynie��?",
		"lista_zyczen.net",
		"HELP? O Co Ci chodzi Skarbie?",
		listaZyczenS,
		lodowka_potwierdzZaprzeczQ,
		2);

	QA *listaZyczen_Q[1] = {listaZyczenQ};
	
	QA *__Q = new QA("_niewazne co powiedziane_",
		"Czy ty mnie w og�le suchasz?,,,,, Powiedzia�am,�e masz jecha� po moj� matk�!,,, A teraz poda� mi �niadanie. Chhc� kaw�, francuskie tosty, po��wk� grejfruta,,,,, [natychmiast]!",
		"bleee_cacy.net", //-------------------------------nad tym trzeba sie jeszcze zastanowic
		"HELP? O Co Ci chodzi Skarbie?",
		__S,
		listaZyczen_Q,
		1);


	QA *bleee_cacyA[2] = {
				new QA("No wiesz?,,,, Chcia�by� tak wygl�da� jak ja! S�siadki zazdroszcz� mi mojej idealnej figury!,,,,, Widz�, �e nie znasz si� na kobiecym pi�knie,, siedzisz wpatrzony w telewizor zamiast podziwia� cud �wiata.,,, Nie chce ju� z tob� rozmawia�.,,, Jad�.,,,, A ty nie zapomnij zrobi�, co kaza�am."),
				new QA("Te� tak s�dz�,,, mo�e nawet przesadzam z t� diet�,,, jedzenie w ci�gu dnia trzech tysi�cy kalorii to za ma�o jak na tak� szczup�� kobiet� jak ja. Od jutra zabieram si� za siebie.,,, To kup jeszcze kilogram p�czk�w jak b�dziesz w sklepie.,,,, Oo.,,,,, dzwoni Kasia. Przez ciebie zapomnia�am o spotkaniu z ni�! ,,,,,,,,,, wstydz si�,,,,,,, jade.")
				};

	QA *blee_cacyQ = new QA("bleee_cacy",
		"Dobrze zrobisz,,, ju� dawno powiniene� zacz�� co� z sob� robi�! Popatrz na siebie! Jak ty wygl�dasz?,,,,,, Jak bym nie wiedzia�a ile sobie robisz jedzenia to bym pomy�la�a, �e ci� w domu �ona nie karmi. ,,,, Sp�jrz na mnie,,,,,,, Czy� nie jestem chodz�cym okazem zdrowia?",
		"bleee_cacy.net",
		"HELP? O Co Ci chodzi Skarbie?",
		bleee_cacyS,
		bleee_cacyA,
		2);

	QA *autobus_rideA = new QA(
			"ahhhhhh,,,,,, w og�le zapomnia�am ci powiedzie�,,,,,, widzisz, jaka zabiegana jestem?,,,,,,,, nnno,,,,,,,,, wi�c po�yczy�am nasz bilet na okaziciela jad�ce, bo musia�a zrobi� sobie now� trwa��,,,,,,, uwierzysz? Nawet tygodnia stara nie wytrzyma�a. Wi�c kup sobie bilet i nie zapomnij go skasowa�.");

	QA *autobusRideA_bleeCacyQ[2] = {autobus_rideA,blee_cacyQ};

	QA *autobusRide_rower = new QA("autobus_ride_rower",
		"Sam widzisz jak du�o musz� za�atwia�, nie mam czasu nawet na przywiezienie dywanu od mojej babci.,,,,,,, Pojedziesz tam autobusem, czy uda ci si� to przywie�� na rowerze?",
		"autobus_ride_rower.net",
		"HELP? O Co Ci chodzi Skarbie?",
		autobusRide_rowerS,
		autobusRideA_bleeCacyQ,
		2);
	
	QA *higienaA[1] = { 
			new QA("No widzisz?,,,,,,, Ja te�,,,,,,,, wi�c, na jakiej podstawie twierdzisz, �e ju� wystarczaj�co si� napracowa�e� i to ja mam wszystko inne robi�?,,, Czy tak trudno jest ugotowa� obiad?,,,,,,,, no,,,,,,, wi�c zr�b go sobie sam. Ja jad�, bo mi zajm� kolejk�.")
			};
	
	QA *higienaQ = new QA("higiena",
		"Ca�y dom mam na utrzymaniu, nic mi nie pomagasz. Wracasz z tej pracy i my�lisz, �e ju� nic nie musisz robi�? Co z tego, �e pracujesz dwana�cie godzin i jeste� naszym jedynym �r�d�em utrzymania? Ja tu siedz� ca�y dzie� i czekam, a� w ko�cu przyjedziesz abym mog�a dowiedzie� si�, co na �wiecie si� dzieje. Przez telefon nie da si� wszystkiego dowiedzie�. ,,,,,W og�le to nie to samo. Ale co ty mo�esz o tym wiedzie�. Co dzisiaj ju� zrobi�e�?,,,,,, umy�e� si�,,,,, z�by wyczy�ci�e�?",
		"higiena.net",
		"HELP? O Co Ci chodzi Skarbie?",
		higienaS,
		higienaA,
		1);

	QA *autobusrideRower__Q[2] = {autobusRide_rower,higienaQ};

	QA *potwierdzObaw_ZaprzeczObawQ = new QA("potwierdzenie_obow_zaprzecz",
		"No to jak b�dziesz siedzie� w domu, to nie zapomnij pozmywa� i zrobi� pranie. Ja nie mam na to w og�le czasu. Musz� jeszcze jecha� do oli, m�wi�a, �e co� ciekawego si� ostatnio wydarzy�o, a chyba nie chcesz, aby mnie taka informacja omin�a? ,,,,,,,,,dobrze,,,,,,,,, a pami�tasz o zrobieniu zakup�w?",
		"potwierdzenie_obow_zaprzecz.net",
		"HELP? O Co Ci chodzi Skarbie?",
		potwierdzObaw_ZaprzeczObawS,
		autobusrideRower__Q,
		2);

	QA *gitZakup_bleeeZakupA[2] = { 
			new QA("Inaczej by� nie mog�o.,, Wyda�am na ni� cztery tysi�ce z�otych. Ale teraz znalaz�am prawdziw� pere�k�. Wi�c nie tra� czasu na gadanie tylko id� wypracowywa� nadgodziny, bo ta kosztuje osiem tysi�cy z�otych."),
			new QA("Jak to ci si� nie podoba?,,,,, Co ty sobie w og�le wyobra�asz?,, �miesz mi doradza�, co jest trendy, a co nie?,,, A niby sk�d masz to wiedzie� jak ca�e dnie sp�dzasz pracuj�c, a wieczorami zajmujesz si� domem?,,,,, Ja staram si�, cho� nie jest to �atwe, znajdowa� czas na wszystko.,,,,,,,,,, Teraz w�a�nie wychodz�.")
			};

	QA *gitZakupy_bleeeZakupyQ = new QA("git_zakup_blee",
		"Sam widzisz,,,, jak du�o wnios�am do tego samochodu., Nawet o�miel� si� powiedzie�, �e wi�cej od Ciebie. Pieni�dze to ka�dy potrafi wydawa�,,, a robi� to m�drze to tylko ja.,,,, No sam powiedz, podoba�a ci si� moja ostatnia sukienka, kt�r� kupi�am?",
		"git_zakup_blee.net",
		"HELP? O Co Ci chodzi Skarbie?",
		gitZakup_bleeeZakupS,
		gitZakup_bleeeZakupA,
		2);

	QA *goodPsie_badPsieA[2] = { 
			new QA("Tyle, chocia� pami�tasz.,,, Ja nie wiem, co masz innego do pami�tania. Przecie� to takie wa�ne. oo.,,,,, Ja ju� musz� lecie�. Nie zapomnij o niczym, co masz zrobi�, bo jutro, b�dziesz musia� wsta� i zrobi� to przed wyj�ciem do pracy."),
			new QA("No wiesz?,,,,, Chcesz, aby nasza pusia zachorowa�a?,,,, Pami�tasz, co si� sta�o, jak kiedy� przez przypadek to zjad�a?,,,, Weterynarz musia� j� zatrzyma� na ca�y dzie� bada�, bo nie wiedzieli, co jej dolega. Na szcz�cie nast�pnego dnia ju� powiedzieli, �e nic jej nie jest.,,, Ale czy ty wiesz jak to si� mog�o sko�czy�?,,,,,,,,, ��miejesz [si�]?,,,,,,, Chyba zapomnia�e�, co masz dzisiaj zrobi�?,,,, Wi�c bie� si� do roboty! Jak wr�c� to ma by� wszystko gotowe!")
			};

	QA *goodPsie_badPsieQ = new QA("good_psie_zarcie",
		"Niewdzi�cznik jeste�, co z tego, �e kolor do dzisiaj ci si� nie podoba,,, albo,, �e niewygodne s� siedzenia,,,, albo nawet taka pierdo�a, jak fakt, �e koledzy �miej� si�, �e je�dzisz r�owym fordem ka? ,,,..czy nie widzisz jak �licznie nasza pusia wygl�da na siedzeniu pasa�era?,, A ta jej r�owa kokardka,,,,, �liczna,,,,,,, w�a�nie,,, jak j� pojad�, to wynie� pusi� na spacer. Nie� ja na poduszeczce i pami�taj aby si� nie przem�czy�a.,, A po spacerze nakarm j�.,,,,,, Pami�tasz, co je?,,,,,,,, Chude piersi z kurczaka, czy pedigripal?",
		"good_psie_zarcie.net",
		"HELP? O Co Ci chodzi Skarbie?",
		goodPsie_badPsieS,
		goodPsie_badPsieA,
		2);

	QA *gitBleee_goodBadPsieQ[2] = {gitZakupy_bleeeZakupyQ,goodPsie_badPsieQ};

	QA *damfureNie_damfureQ = new QA("dam_fure_niedam",
		"Wiedzia�am, �e si� b�dziesz ba� mi da� samoch�d. Wydaje ci si�, �e nie potrafi� je�dzi�!, Ale ola spod pi�tnastki te� mia�a st�uczk�., Co prawda potrzaska�a tylko prz�d samochodu, a ja r�wnie� oba boki i ty�,,, ale czy chcesz mi powiedzie�, �e to jaka� r�nica?,,,, Przecie� g�upia nie jestem.,,,, Ona uszkodzi�a samoch�d i ja te�, wi�c, o co chodzi?,,,,, Tak,,,, wiem,, szukasz tylko jakiego� pretekstu, aby mi go nie dawa�,, ale pami�taj, �e ten samoch�d te� jest moj� w�asno�ci�. Przecie� to ja go wybra�am.,,,,,, Wi�c dasz mi go?",
		"dam_fure_niedam.net",
		"HELP? O Co Ci chodzi Skarbie?",
		gitBleee_goodBadPsieS,
		gitBleee_goodBadPsieQ,
		2);

	QA *potobawZapobaw_damfureNiedamfureQ[2] = {potwierdzObaw_ZaprzeczObawQ,damfureNie_damfureQ};
	
	QA *wezfure_zawiozeQ = new QA("wez_fure_zawioze",
		"Widzisz, jaka jestem zabiegana?,, Ca�y czas kto�, co� ode mnie chce,,, a ja nie potrafi� znale�� czasu.,,,, Dobrze, �e masz tak du�o czasu po pracy, bo ja musia�am ze swojej zrezygnowa�, aby m�c wype�nia� wszystkie obowi�zki domowe.,, A w�a�nie,, musz� jecha� zaraz do fryzjera.,,,, Chcesz mnie zawie��, czy mam zabra� samoch�d?",
		"wez_fure_zawioze.net",
		"HELP? O Co Ci chodzi Skarbie?",
		wezfure_zawiozeS,
		potobawZapobaw_damfureNiedamfureQ,
		2);

	QA *wezfureZawioze___Q[2] = {wezfure_zawiozeQ,__Q};

	QA *zrob_kochanieA[1] = { 
			new QA("Dobrze kotku, to ja ju� zabieram si� za prac�, bo nie chc� �eby� to p�niej Ty musia� robi�. Mi�ego dnia. Kocham Ci� bardzo. A w nocy zobaczysz, co m�j nowy chirurg plastyczny dla ciebie zrobi�.")
		};

	QA *matka_wyjazdQ_PrzyjazdA[2] = { 
			new QA("zrob_kochanie",
				   "ahhhh,,,, jaki Ty jeste� dzisiaj wspania�y.,,, To w�a�nie sobie sprawi�e� wolny wiecz�r. Zapro� koleg�w, a ja zrobi� kanapki, kupi� piwo i b�dziecie mogli ogl�da� wybory mis mokrego podkoszulka.,,, Jak s�dzisz, co jest do zrobienia wok� domu? Bo mog� w tym czasie: umy� samoch�d, wyprowadzi� psa na d�ugi spacer, zadba� o siebie w klubie fitness a p�niej przyprowadzi� wam bardzo rozrywkowe samotne kole�anki,, przepcha� rur� w sedesie, odpowietrzy� kaloryfery, przystrzyc trawnik,,,,a mo�e pomalowa� dach?",
				   "zrob_kochanie.net",
				   "HELP? O Co Ci chodzi Skarbie?",
				   __S,
				   zrob_kochanieA, 
				   1),
			new QA("W wi�c zadzwo� do koleg�w, i odwo�aj spotkanie, bo musisz jecha� po mamusi�.,, Zbieraj si� od razu, bo masz po ni� by� za dwie godziny, a musisz jeszcze,,, umy� si�, ogoli�, umy� samoch�d, kupi� i u�y� wod� toaletow�, wyprowadzi� psa na d�ugi spacer, przepcha� rur� w sedesie, odpowietrzy� kaloryfery, zrobi� kolacj�, przystrzyc trawnik, pomalowa� dach!,,,,,,, Ahhh, i nie zapomnij by� mi�y dla mamusii., Ja ide pomalowa� paznokcie.")
			};

	QA *matka_wyjazdPrzyjazdQ[1] = {
				new QA("matka_wyjazd_przyjazd",
				"W�a�nie to samo chcia�am wybra� dla siebie. ,,Jeste� taki inteligentny .,,chlip.,,,Jestem najszcz�liwsz� wirtualn� �on� na �wiecie. ,,,Mam jeszcze jeden pomys�.,, Co powiesz na to, abym zadzwoni�a do matki, powiedzia�a �eby nie przyje�dza�a do nas, do p�ki nie przeprosi Ci� za to, ,�e nazwa�a Ci� nierobem?,, Podoba ci si� m�j pomys�?",
				"matka_wyjazd_przyjazd.net",
				"HELP? O Co Ci chodzi Skarbie?",
				matka_wyjazd_przyjazdS,
				matka_wyjazdQ_PrzyjazdA, 
				2),
		};

	QA *danie_mcdQ = new QA("danie_mcd",
		"��wietny wyb�r Skarbie.,, Sama bym tego lepiej nie wymy�li�a. ,A co by� chcia� tam zje��?,, Mamy do wyboru. Zestaw happi mil, big mak, sa�atka cesarska, zestaw maknaggets, kola.",
		"danie_mcd.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_mcdS,
		matka_wyjazdPrzyjazdQ, 
		1);

	QA *danie_spxQ = new QA("danie_spx",
		"��wietny wyb�r Skarbie.,, Sama bym tego lepiej nie wymy�li�a. ,A co by� chcia� tam zje��?,, Mamy do wyboru. Pikantny kebab, szaorma z kurczaka z serem, zestaw sur�wek, piwo.",
		"danie_spx.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_spxS,
		matka_wyjazdPrzyjazdQ, 
		1);

	QA *danie_pizzhQ = new QA("danie_pizzh",
		"��wietny wyb�r Skarbie.,, Sama bym tego lepiej nie wymy�li�a. ,A co by� chcia� tam zje��?,, Mamy do wyboru. Spagetti, pica europejska, pica margeritta, pica pepperoni, wino.",
		"danie_pizzh.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_pizzhS,
		matka_wyjazdPrzyjazdQ, 
		1);

	QA *danie_kfcQ = new QA("danie_kfc",
		"��wietny wyb�r Skarbie.,, Sama bym tego lepiej nie wymy�li�a. ,A co by� chcia� tam zje��?,, Mamy do wyboru. Zestaw okura, t�ister, pikantne skrzyde�ka z kurczaka, pepsy.",
		"danie_kfc.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_kfcS,
		matka_wyjazdPrzyjazdQ, 
		1);

	QA *danie_komppiwQ = new QA("danie_komppiw",
		"��wietny wyb�r Skarbie.,, Sama bym tego lepiej nie wymy�li�a. ,A co by� chcia� tam zje��?,, Mamy do wyboru. Deska mi�s, sa�atka grecka, golonka, czysta.",
		"danie_komppiw.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_komppiwS,
		matka_wyjazdPrzyjazdQ, 
		1);

	QA *danie_pierQ = new QA("danie_pier",
		"��wietny wyb�r Skarbie.,, Sama bym tego lepiej nie wymy�li�a. ,A co by� chcia� tam zje��?,, Mamy do wyboru. Pierogi ruskie, pierogi z mi�sem, pierogi wielkanocne, pierogi rosyjska ruletka, herbata.",
		"danie_pier.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_pierS,
		matka_wyjazdPrzyjazdQ, 
		1);

	QA *danie_mariotQ = new QA("danie_mariot",
		"��wietny wyb�r Skarbie.,, Sama bym tego lepiej nie wymy�li�a. ,A co by� chcia� tam zje��?,, Mamy do wyboru. Indyk w migda�ach, sarnina w sosie grzybowym mi�so z kanadyjskiego �osia w sosie w�asnym, szampan.",
		"danie_mariot.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_mariotS,
		matka_wyjazdPrzyjazdQ, 
		1);

	QA *dania_restauracjeQ[7] = {	danie_mcdQ,
								danie_spxQ,
								danie_pizzhQ,
								danie_kfcQ,
								danie_komppiwQ,
								danie_pierQ,
								danie_mariotQ
							  };

	QA *ktora_restauracjaQ = new QA("ktora_restauracja",
		"Mam bardzo du�o pieni�dzy, bo uzna�am, �e kupowanie sobie dziesi�ciu krem�w na noc to jest zb�dny wydatek., Wi�c masz do wyboru. Makdonalda, sfinksa, picahat, kejefssii, kompania piwna, pierogarnia na star�wce, restauracja w mariocie?",
		"ktora_restauracja.net",
		"HELP? O Co Ci chodzi Skarbie?",
		ktora_restauracjaS,
		dania_restauracjeQ, 
		7);

	QA *kino_domoweA[2] = { 
			new QA("Dobrze kochanie, to ja zabieram si� za to,,, co mam do zrobienia, a Ty nie przem�czaj si�,,, po��, i nie r�b najlepiej nnniicc,, bo ju� dzisiaj si� wystarczaj�co napracowa�e�, wstaj�c.,,,, Jeste� taki cudowny, bardzo przyjemnie mi patrze� na ciebie, a ten przepocony podkoszulek i dresowe spodnie tylko dodaj� ci uroku.,, No i ten pi�ciodniowy zarost.,,, Idea�."),
		   new QA("Widz�, �e zawsze co� ci musi nie pasowa�, jeste� starym leniwym capem!, Mamusia mia�a racj� co do ciebie,, ja si� staram od samego rana a ty tylko wybrzydzasz.,, We� si� za robot�!, A jak nie zrobisz, to nici z wieczoru z kumplami i z seksu przez najbli�szy miesi�c!,, Ale ja g�upia by�am!,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, Do roboty!")
		};

	QA *kino_domoweQ[1] = {new QA("kino_domowe",
		"Doskonale., Zostanie mi jeszcze troch� pieni�dzy, kt�re mamusia da�a mi na moje urodziny,, �ebym kupi�a sobie nowe spodnie.,, Ale po co mi kolejny ciuch?,,, Pomy�la�am, �e mo�e dokupi� do tego zestaw kina domowego, aby podnie�� wam komfort ogl�dania?",
		"kino_domowe.net",
		"HELP? O Co Ci chodzi Skarbie?",
		kino_domoweS,
		kino_domoweA, 
		2)};

	QA *telewizorQ[1] = {new QA("telewizor",
		"��wietny wyb�r.,, A czy konkurs mokrych podkoszulek, b�dzie dobrze wygl�da� na tym gracie?,, Wszyscy Twoi kumple maj� ju� co� nowszego. Wi�c mo�e chcia�by�, abym kupi�a nowy,, du�y i z p�askim kineskopem telewizor?,,, Jaki by spe�nia� twoje wymagania? Sony dwadzie�ciadziewi�� cali, philips trzydzie�ci cali, sanjo dwadzie�ciadziewi�� cali, panasonik czterdzie�cipi�� cali?",
		"telewizor.net",
		"HELP? O Co Ci chodzi Skarbie?",
		telewizorS,
		kino_domoweQ, 
		1)};


	QA *zakaskiQ = new QA("zakaski",
		"��wietnie, bo jak dobrze pami�tam, wieczorem maj� przyj�� Twoi kumple. ,,Co by� chcia� abym dla was przygotowa�a na wiecz�r?,,,, Kanapki, czipsy, s�odycze, pice, kole?",
		"zakaski.net",
		"HELP? O Co Ci chodzi Skarbie?",
		zakaskiS,
		telewizorQ, 
		1);

	QA *kiedys_nigdyA[2] = { 
			new QA("Zawsze czu�am, �e jeste� draniem. W dniu naszego [�lubu], [musia�am] by� na prochach! Gdybym trze�wo my�la�a,[nnniigdy] [bym] za ciebie nie wysz�a! Jeste� beznadziejny! Wyno� si� z mojego mieszkania! Mam do�� twoich brudnych skarpetek, tego, �e nie zamykasz deski klozetowej,,a najbardziej nie lubi� tego,�e wyciskasz past� do z�b�w od �rodka tubki! Powiniene� to robi� od ko�ca!,,,, A i nawet ten siedemdziesi�cioletni listonosz jest lepszy od ciebie w ��ku!"),
		    new QA("ty [mnie] ju� [nie] [kochasz]!")
		};

	QA *nigdy_kiedysQ = new QA("kiedys_nigdy",
		"Niechcesz �ebym Ci pomaga�a.,,,,,,, :( Wyje�dzam do mamusii!,,,,,,,,,, nie wiem,kiedy wr�c�!,,,,,,,,,,,,,,,to mam wr�ci� jutro?, za tydzie�?, za [miesi�c]?, [nigdy]?",
		"kiedys_nigdy.net",
		"HELP? O Co Ci chodzi Skarbie?",
		kiedys_nigdyS,
		kiedys_nigdyA, 
		2);

	QA *zakaski_nigdyKiedysQ[2] = {zakaskiQ,nigdy_kiedysQ};

	QA *piwo_tak_nieQ = new QA("piwo_tak_nie",
		"Jak mi�o,,�e lubisz jak gotuj�. To mam jeszcze propozycj�. Mo�e zechcia�by� abym kupi�a zimne piwo na wieczorny mecz?",
		"piwo_tak_nie.net",
		"HELP? O Co Ci chodzi Skarbie?",
		piwo_tak_nieS,
		zakaski_nigdyKiedysQ, 
		2);

	QA *piwoTAKnie_ktoraRestauracjaQ[2] = {piwo_tak_nieQ,ktora_restauracjaQ};

	QA *matkaride__Q = new QA("matka_ride",
		"Co chcesz zrobi� najpiew?,,,Mo�e,, przywie� moj� Mam�?",
		"matka_ride.net",
		"HELP? O Co Ci chodzi Skarbie?",
		matkaride__S,
		wezfureZawioze___Q,
		2);

	QA *danie_restauracjeQ = new QA("danie_restauracje",
		"Zastanawiam si�,, ugotowa� Twoje ulubione danie,,,czy zaprosi� Ci� do restauracjj?",
		"danie_restauracje.net",
		"HELP? O Co Ci chodzi Skarbie?",
		danie_restauracjeS,
		piwoTAKnie_ktoraRestauracjaQ, 
		2);
	
	QA *restDanie_matkaride__Q[2] = {danie_restauracjeQ,matkaride__Q};

	QA *aniolek_diablicaQ = new QA("aniolek_diablica",
		"Witaj z�otko,,,chcia�by� abym dziasiaj by�a Twoim anio�kiem,, czy diablic�?",
		"aniolek_diablica.net",
		"HELP? O Co Ci chodzi Skarbie?",
		aniolek_diablicaS,
		restDanie_matkaride__Q,
		2);

		QA *koniecA = new QA("do zobaczenia Skarbie, ja znikam...");

	QA *petla[2] = {aniolek_diablicaQ,koniecA};

	QA *porozmawiajnyQ = new QA("tak_nie",
		"Chcia�by� jeszcze raze mn� porozmawia�?",
		"porozmawiajmy.net",
		"powiedz TAK lub NIE",
		porozmawiajmyS,
		petla,
		2);

	// Start recogniser running
	StartRecogniser();
	aniolek_diablicaQ->GetSlot();	
	porozmawiajnyQ->GetSlot();
	while(porozmawiajnyQ->value == "tak"){
		porozmawiajnyQ->GetSlot();
	}

	printf("\n\n================BYE==================\n\n");
}

// --------------------------- Main Program ----------------------------

int main(int argc, char *argv[])
{
  try {
    Initialise(argc,argv);
    BuildRecogniser();
    RunApplication();
  }
  catch (ATK_Error e){
    int n = HRErrorCount();
    printf("ATK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
  catch (HTK_Error e){
    int n = HRErrorCount();
    printf("HTK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
  return 0;
}

// ------------------------- End KxL -----------------------------
